package ynu.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProviderApplication11001 {
    public static void main(String[] args) {
        SpringApplication.run(ProviderApplication11001.class, args);
    }
}
