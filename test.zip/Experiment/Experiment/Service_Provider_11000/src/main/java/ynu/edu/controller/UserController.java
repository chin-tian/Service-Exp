package ynu.edu.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {


    @GetMapping("/orders/{orderId}")
    public String getOrderDetails(@PathVariable("orderId") int orderId) {
        // 硬编码返回指定的JSON内容
        return "{\"orderId\": 123, \"userId\": 1, \"totalAmount\": 100.0, \"status\": \"待支付\", \"createdAt\": \"2025-06-28T10:30:00\"}";
    }

    @PostMapping("/orders/{orderId}/pay")
    public String payOrder(@PathVariable("orderId") int orderId) {
        // 硬编码返回指定的JSON内容
        return "{\"orderId\": 123, \"userId\": 1, \"totalAmount\": 100.0, \"status\": \"已支付\", \"createdAt\": \"2025-06-25T10:30:00\"}";
    }
    @PutMapping("/users/{userId}/password")
    public String updateUserPassword(@PathVariable("userId") int userId, @RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"userId\": 1, \"username\": \"john_doe\", \"email\": \"johndoe@example.com\"}";
    }

    @PostMapping("/merchants/register")
    public String registerMerchant(@RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"merchantId\": 1, \"shopName\": \"New Shop Name\", \"ownerName\": \"John Doe\", \"contactInfo\": \"123-456-7890\"}";
    }

    @PutMapping("/merchants/{merchantId}")
    public String updateMerchant(@PathVariable("merchantId") int merchantId, @RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"merchantId\": 1, \"shopName\": \"New Shop Name\", \"ownerName\": \"John Doe\", \"contactInfo\": \"123-456-7890\"}";
    }

    @PostMapping("/products/add")
    public String addProduct(@RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"productId\": 1, \"name\": \"Product A\", \"description\": \"This is a great product.\", \"price\": 99.99, \"merchantId\": 1}";
    }

    @PutMapping("/products/{productId}")
    public String updateProduct(@PathVariable("productId") int productId, @RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"productId\": 1, \"name\": \"Updated Product A\", \"description\": \"Updated description.\", \"price\": 79.99, \"merchantId\": 1}";
    }

    @DeleteMapping("/products/{productId}")
    public ResponseEntity<Void> deleteProduct(@PathVariable("productId") int productId) {
        // 返回状态码204 No Content
        return ResponseEntity.noContent().build();
    }














    @PostMapping("/orders/create")
    public String createOrder(@RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"orderId\": 123, \"userId\": 1, \"totalAmount\": 100.0, \"status\": \"待支付\", \"createdAt\": \"2025-06-28T10:30:00\"}";
    }

    @PutMapping("/deliverytasks/{taskId}/status")
    public String updateDeliveryTaskStatus(@PathVariable("taskId") int taskId, @RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"taskId\": " + taskId + ", \"orderId\": 1001, \"deliveryManId\": 1, \"status\": \"in_progress\"}";
    }
    @PostMapping("/deliverytasks/assign")
    public String assignDeliveryTask(@RequestParam("orderId") int orderId, @RequestParam("deliveryManId") int deliveryManId) {
        // 硬编码返回指定的JSON内容
        return "{\"taskId\": 1, \"orderId\": 1001, \"deliveryManId\": 1, \"status\": \"assigned\"}";
    }

    @GetMapping("/deliverymen/{id}")
    public String getDeliveryMan(@PathVariable("id") int id) {
        // 硬编码返回指定的JSON内容
        return "{\"id\": 1, \"name\": \"John Doe\", \"phone\": \"0987654321\", \"status\": \"busy\"}";
    }
    @PostMapping("/deliverymen/register")
    public String registerDeliveryMan(@RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"id\": 1, \"name\": \"John Doe\", \"phone\": \"1234567890\", \"status\": \"available\"}";
    }

    @PutMapping("/deliverymen/{id}")
    public String updateDeliveryMan(@PathVariable("id") int id, @RequestBody String requestBody) {
        // 硬编码返回指定的JSON内容
        return "{\"id\": 1, \"name\": \"John Doe\", \"phone\": \"0987654321\", \"status\": \"busy\"}";
    }
    @GetMapping("/orders/merchant/{merchantId}")
    public String getMerchantOrders(@PathVariable("merchantId") int merchantId) {
        // 硬编码返回指定的JSON内容
        return "["
                + "{\"orderId\": 1, \"merchantId\": 1, \"customerId\": 2, \"totalAmount\": 59.99, \"status\": \"pending\"},"
                + "{\"orderId\": 2, \"merchantId\": 1, \"customerId\": 3, \"totalAmount\": 39.99, \"status\": \"completed\"}"
                + "]";
    }



//    @GetMapping("/get/{id}")
    @GetMapping("/get/{id}")
    public String getUser(@PathVariable("id") String id) {
//        return "{\"id\": \"" + id + "\", \"name\": \"John Doe\"}";
        return "{\"message\": \"User created successfully\"}";
    }

    //    @GetMapping("/get/{id}")
    @GetMapping("/post/{id}")
    public String getUser2(@PathVariable("id") String id) {
//        return "{\"id\": \"" + id + "\", \"name\": \"John Doe\"}";
        return "{\"message\": \"Product created successfully\"}";
    }

    //    @GetMapping("/get/{id}")
    @GetMapping("/put/{id}")
    public String getUser3(@PathVariable("id") String id) {
//        return "{\"id\": \"" + id + "\", \"name\": \"John Doe\"}";
//        return "{\"message\": \"This is User1!\"}";
        return null;
//        return "{\"message\": \"User with id " + id + " updated successfully\"}";
    }

    //    @GetMapping("/get/{id}")
    @GetMapping("/delete/{id}")
    public String getUser4(@PathVariable("id") String id) {
//        return "{\"id\": \"" + id + "\", \"name\": \"John Doe\"}";
        return "{\"message\": \"This is User2!\"}";
//        return "{\"message\": \"User with id " + id + " deleted successfully\"}";
    }

    @PostMapping("/post")
    public String createUser() {
        return "{\"message\": \"User created successfully\"}";
    }

    @PutMapping("/put/{id}")
    public String updateUser(@PathVariable("id") String id) {
        return "{\"message\": \"User with id " + id + " updated successfully\"}";
    }

    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable("id") String id) {
        return "{\"message\": \"User with id " + id + " deleted successfully\"}";
    }
}




//package ynu.edu.controller;
//
//
//import org.springframework.web.bind.annotation.*;
//import ynu.edu.entity.User;
//
//@RestController
//@RequestMapping("/api/users")
//public class UserController {
//
//    @GetMapping("/{id}")
//    public String getUser(@PathVariable("id") String id) {
////        return new User(id, "John Doe");
//        return "1 Jhon Doe";
//    }
//
//    @PostMapping("/")
//    public User createUser(@RequestBody User user) {
////        user.setId("123");
//        return user;
//    }
//
//    @PutMapping("/{id}")
//    public User updateUser(@PathVariable("id") String id, @RequestBody User user) {
////        user.setId(id);
//        return user;
//    }
//
//    @DeleteMapping("/{id}")
//    public String deleteUser(@PathVariable("id") String id) {
//        return "User with id " + id + " deleted.";
//    }
//}


//@RestController
//@RequestMapping("/api/user")
//public class UserController {
//    @GetMapping("/getUserById/{userId}")
//    public User GetUserById(@PathVariable("userId") Integer userId){
//        User user = new User();
//        user.setUserId(userId);
//        user.setUserName("小明 from 11000");
//        user.setPassWord("123456");
//        return user;
//    }
//}
