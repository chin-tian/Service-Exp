package ynu.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProviderApplication11000 {
    public static void main(String[] args) {
        SpringApplication.run(ProviderApplication11000.class, args);
    }
}
